import * as React from "react";

interface IOrdersProps {}

const Orders: React.FunctionComponent<IOrdersProps> = (props) => {
  return (
    <>
      <h3>Orders</h3>
    </>
  );
};

export default Orders;
