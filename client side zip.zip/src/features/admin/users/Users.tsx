import * as React from "react";
import UserService from "../../../services/UserService";

interface IDashboardProps {}

const Users: React.FunctionComponent<IDashboardProps> = (props) => {
  React.useEffect(() => {
    UserService.fetchAllUser()
      .then((response) => {
        console.log("Data:", response?.data?.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  return (
    <>
      <h3>Users</h3>
    </>
  );
};

export default Users;
