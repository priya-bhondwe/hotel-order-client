import * as React from 'react';

interface IHomeProps {
}

const Home: React.FunctionComponent<IHomeProps> = (props) => {
  return <>
  <h3>Home</h3>
  </>
};

export default Home;
