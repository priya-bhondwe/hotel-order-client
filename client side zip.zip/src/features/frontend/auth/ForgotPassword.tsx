import * as React from 'react';
import { Container,Card } from '@mui/material';
interface IForgotPasswordProps {
}

const ForgotPassword: React.FunctionComponent<IForgotPasswordProps> = (props) => {
  return (
    <>
    
    </>
  )
};

export default ForgotPassword;
