import * as React from 'react';

interface IFeedbackProps {
}

const Feedback: React.FunctionComponent<IFeedbackProps> = (props) => {
  return <>
  <h3>Feedback</h3>
  </>
};

export default Feedback;
