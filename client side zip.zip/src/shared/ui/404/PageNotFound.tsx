import * as React from "react";

interface IPageNotFoundProps {}

const PageNotFound: React.FunctionComponent<IPageNotFoundProps> = (props) => {
  return (
    <>
      <h3>Page Not Found</h3>
    </>
  );
};

export default PageNotFound;
