import { lazy } from "react";
import DashboardIcon from "@mui/icons-material/Dashboard";
import DishesIcon from "@mui/icons-material/DiningSharp";
import OrdersIcon from "@mui/icons-material/Book";
import UsersIcon from "@mui/icons-material/PeopleSharp";

const Dashboard = lazy(
  () => import("../../features/admin/dashboard/Dashboard")
);
const Dishes = lazy(() => import("../../features/admin/dishes/Dishes"));
const Orders = lazy(() => import("../../features/admin/orders/Orders"));
const Users = lazy(() => import("../../features/admin/users/Users"));

export default [
  {
    label: "Dashboard",
    component: <Dashboard />,
    path: "",
    icon: <DashboardIcon />,
    showInMenu: true,
    roles: ["admin", "superadmin"],
  },
  {
    label: "Orders",
    component: <Orders />,
    path: "orders",
    icon: <OrdersIcon />,
    showInMenu: true,
    roles: ["admin", "superadmin"],
  },
  {
    label: "Dishes",
    component: <Dishes />,
    path: "dishes",
    icon: <DishesIcon />,
    showInMenu: true,
    roles: ["superadmin"],
  },
  {
    label: "Users",
    component: <Users />,
    path: "users",
    icon: <UsersIcon />,
    showInMenu: true,
    roles: ["superadmin"],
  },
];
