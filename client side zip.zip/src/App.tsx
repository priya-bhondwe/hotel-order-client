import * as React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import BlackLayout from "./layouts/blank/BlackLayout";
import FullLayout from "./layouts/full/FullLayout";
import PageNotFound from "./shared/ui/404/PageNotFound";
import { ToastContainer } from "react-toastify";
import { useSelector } from "react-redux";
import { selectUser } from "./app/slice/authSlice";

interface IProtectedRoutes {
  children: React.ReactElement;
}

const ProtectedRoute: React.FunctionComponent<IProtectedRoutes> = ({
  children
}) => {
  // get logged user from redux state
  //access from redux state
  const loggedUser = useSelector(selectUser);
  return loggedUser?._id ? children : <Navigate to="/login" />;
};

interface IAppProps {}
const App: React.FunctionComponent<IAppProps> = (props) => {
  return (
    <>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      <Routes>
        <Route path="/*" element={<BlackLayout />} />
        <Route
          path="secured/*"
          element={
            <ProtectedRoute>
              <FullLayout />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </>
  );
};

export default App;
