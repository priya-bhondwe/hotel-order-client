import * as React from "react";
import { Routes, Route } from "react-router-dom";
import BlackLayout from "./layouts/blank/BlackLayout";
import FullLayout from "./layouts/full/FullLayout";
import PageNotFound from "./shared/ui/404/PageNotFound";
interface IAppProps {}

const App: React.FunctionComponent<IAppProps> = (props) => {
  return (
    <>
      <Routes>
        <Route path="/*" element={<BlackLayout />} />
        <Route path="secured/*" element={<FullLayout />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </>
  );
};

export default App;
