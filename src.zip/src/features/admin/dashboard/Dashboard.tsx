import * as React from "react";

interface IDashboardProps {}

const Dashboard: React.FunctionComponent<IDashboardProps> = (props) => {
  return (
    <>
      <h3>Dashboard</h3>
    </>
  );
};

export default Dashboard;
