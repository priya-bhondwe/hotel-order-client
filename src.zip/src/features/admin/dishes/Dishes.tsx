import * as React from "react";

interface IDishesProps {}

const Dishes: React.FunctionComponent<IDishesProps> = (props) => {
  return (
    <>
      <h3>Dishes</h3>
    </>
  );
};

export default Dishes;
