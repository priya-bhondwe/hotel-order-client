import * as React from "react";

interface IUsersProps {}

const Users: React.FunctionComponent<IUsersProps> = (props) => {
  return (
    <>
      <h3>Users</h3>
    </>
  );
};

export default Users;
