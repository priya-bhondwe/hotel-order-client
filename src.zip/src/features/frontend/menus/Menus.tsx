import * as React from "react";

interface IMenusProps {}

const Menus: React.FunctionComponent<IMenusProps> = (props) => {
  return (
    <>
      <h3>Menus</h3>
    </>
  );
};

export default Menus;
