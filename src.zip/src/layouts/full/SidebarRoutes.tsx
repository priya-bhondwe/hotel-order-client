import { Suspense } from "react";
import { Routes, Route } from "react-router-dom";
import adminRoutes from "../../shared/routes/adminRoutes";

interface ISidebarRoutesProps {}

const SidebarRoutes: React.FunctionComponent<ISidebarRoutesProps> = (props) => {
  return (
    <>
      <Suspense>
        <Routes>
          {Array.isArray(adminRoutes) &&
            adminRoutes?.map(({ path, component }, i) => (
              <Route key={i} path={path} element={component} />
            ))}
        </Routes>
      </Suspense>
    </>
  );
};

export default SidebarRoutes;
