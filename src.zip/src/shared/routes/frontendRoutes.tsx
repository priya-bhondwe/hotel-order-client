import { lazy } from "react";
import Menus from "../../features/frontend/menus/Menus";

const Home = lazy(() => import("../../features/frontend/home/Home"));
const Menu = lazy(() => import("../../features/frontend/menus/Menus"));
const Login = lazy(() => import("../../features/frontend/login/Login"));
const Feedback = lazy(
  () => import("../../features/frontend/feedback/Feedback")
);

export default [
  {
    label: "Home",
    path: "",
    component: <Home />,
  },
  {
    label: "Menus",
    path: "menus",
    component: <Menus />,
  },
  {
    label: "Feedback",
    path: "feedback",
    component: <Feedback />,
  },
  {
    label: "Login",
    path: "login",
    component: <Login />,
  },
];
